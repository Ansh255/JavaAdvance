package com.kunal.enumExamples;

public interface A {
    void hello();
}
