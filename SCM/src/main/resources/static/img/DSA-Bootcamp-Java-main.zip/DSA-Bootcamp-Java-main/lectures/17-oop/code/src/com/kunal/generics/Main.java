package com.kunal.generics;

public class Main implements GenericInterface<Integer>{

    @Override
    public void display(Integer value) {

    }
}
