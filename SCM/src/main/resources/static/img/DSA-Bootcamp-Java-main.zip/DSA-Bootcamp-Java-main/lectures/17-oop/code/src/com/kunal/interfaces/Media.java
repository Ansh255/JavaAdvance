package com.kunal.interfaces;

public interface Media {
    void start();
    void stop();
}
