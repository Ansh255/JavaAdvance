package com.kunal.interfaces.extendDemo;

public interface B extends A{
    void greet();
}
