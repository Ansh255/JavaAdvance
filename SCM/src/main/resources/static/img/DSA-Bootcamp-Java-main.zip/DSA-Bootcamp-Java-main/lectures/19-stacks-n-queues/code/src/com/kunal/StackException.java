package com.kunal;

public class StackException extends Exception{

    public StackException(String message) {
        super(message);
    }
}
